import numpy as np
import subprocess
import os
import tempfile
from typing import List

from reinvent_scoring.scoring.utils import _is_development_environment

from reinvent_scoring.scoring.component_parameters import ComponentParameters
from reinvent_scoring.scoring.score_components.structural.base_structural_component import BaseStructuralComponent


class DockStream(BaseStructuralComponent):
    def __init__(self, parameters: ComponentParameters):
        super().__init__(parameters)
        self._configuration_path = self.parameters.specific_parameters[self.component_specific_parameters.DOCKSTREAM_CONFPATH]
        self._docker_script_path = self.parameters.specific_parameters[self.component_specific_parameters.DOCKSTREAM_DOCKERSCRIPTPATH]
        self._environment_path = self.parameters.specific_parameters[self.component_specific_parameters.DOCKSTREAM_ENVPATH]

        # Enable debug mode by default for troubleshooting
        self._debug_mode = self.parameters.specific_parameters.get(self.component_specific_parameters.DOCKSTREAM_DEBUG, True)

        if self._debug_mode:
            print(f"🔧 DockStream Debug Mode Enabled")
            print(f"   Configuration path: {self._configuration_path}")
            print(f"   Docker script path: {self._docker_script_path}")
            print(f"   Environment path: {self._environment_path}")

    def _add_debug_mode_if_selected(self, command):
        if self.parameters.specific_parameters.get(self.component_specific_parameters.DOCKSTREAM_DEBUG, False)\
                or _is_development_environment():
            command = ' '.join([command, "-debug"])
        return command

    def _create_command(self, smiles: List[str], step):
        concat_smiles = '"' + ';'.join(smiles) + '"'
        command = ' '.join([self._environment_path,
                            self._docker_script_path,
                            "-conf", self._configuration_path,
                            "-output_prefix", self._get_step_string(step),
                            "-smiles", concat_smiles,
                            "-print_scores"])

        # check, if DockStream is to be executed in debug mode, which will cause its loggers to print out
        # much more detailed information
        command = self._add_debug_mode_if_selected(command)
        return command

    def _calculate_score(self, smiles: List[str], step) -> np.array:
        if self._debug_mode:
            print(f"\n🧮 DockStream calculating scores for {len(smiles)} molecules at step {step}")
            print(f"   SMILES: {smiles[:3]}{'...' if len(smiles) > 3 else ''}")

        # create the external command
        command = self._create_command(smiles, step)

        if self._debug_mode:
            print(f"   Command: {command}")

        # Test command execution with detailed error handling
        try:
            # send the batch smiles and retrieve the result as a list of strings
            results = self._send_request_with_stepwize_read_debug(command, len(smiles))

            if self._debug_mode:
                print(f"   Raw results: {results}")

        except Exception as e:
            print(f"❌ DockStream command execution failed: {e}")
            # Return zeros for all molecules if command fails
            results = ["0"] * len(smiles)

        # note: some ligands might have failed in DockStream (embedding or docking) although they are valid
        #       RDkit molecules -> "docker.py" will return "NA"'s for failed molecules, as '0' could be a perfectly
        #       normal value; anything that cannot be cast to a floating point number will result in '0'
        scores = []
        for i, score in enumerate(results):
            try:
                score_val = float(score)
                if self._debug_mode and i < 3:  # Show first 3 scores
                    print(f"   Score {i}: {score} -> {score_val}")
            except ValueError:
                score_val = 0
                if self._debug_mode and i < 3:
                    print(f"   Score {i}: {score} -> 0 (conversion failed)")
            scores.append(score_val)

        transform_params = self.parameters.specific_parameters.get(
            self.component_specific_parameters.TRANSFORMATION, {}
        )
        transformed_scores = self._transformation_function(scores, transform_params)

        if self._debug_mode:
            print(f"   Final scores: {scores[:3]}{'...' if len(scores) > 3 else ''}")
            print(f"   Transformed scores: {transformed_scores[:3]}{'...' if len(transformed_scores) > 3 else ''}")

        return np.array(transformed_scores), np.array(scores)

    def _send_request_with_stepwize_read_debug(self, command, data_size: int):
        """Enhanced version with detailed debugging"""
        if self._debug_mode:
            print(f"   Executing command with subprocess...")

        # Create a temporary file to capture stderr
        with tempfile.NamedTemporaryFile(mode='w+', delete=False, suffix='.log') as stderr_file:
            stderr_path = stderr_file.name

        try:
            with subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=True, text=True) as proc:

                stdout, stderr = proc.communicate(timeout=300)  # 5 minute timeout

                if self._debug_mode:
                    print(f"   Return code: {proc.returncode}")
                    if stdout:
                        print(f"   STDOUT: {stdout[:500]}{'...' if len(stdout) > 500 else ''}")
                    if stderr:
                        print(f"   STDERR: {stderr[:500]}{'...' if len(stderr) > 500 else ''}")

                if proc.returncode != 0:
                    raise RuntimeError(f"DockStream command failed with return code {proc.returncode}. STDERR: {stderr}")

                # Parse stdout for scores
                lines = stdout.strip().split('\n')
                result = []

                # Look for numeric scores in the output
                for line in lines:
                    line = line.strip()
                    if line and not line.startswith('#') and not line.startswith('INFO'):
                        try:
                            # Try to parse as float
                            float(line)
                            result.append(line)
                        except ValueError:
                            # Skip non-numeric lines
                            continue

                if self._debug_mode:
                    print(f"   Parsed {len(result)} scores from output")

                # If we don't have enough scores, pad with zeros
                while len(result) < data_size:
                    result.append("0")

                return result[:data_size]

        except subprocess.TimeoutExpired:
            print(f"❌ DockStream command timed out after 5 minutes")
            return ["0"] * data_size
        except Exception as e:
            print(f"❌ DockStream subprocess error: {e}")
            return ["0"] * data_size
        finally:
            # Clean up temporary file
            if os.path.exists(stderr_path):
                os.unlink(stderr_path)

    def _parse_result(self, result):
        return str(result).strip()
