from reinvent_scoring.scoring.score_components.console_invoked.icolos import Icolos
